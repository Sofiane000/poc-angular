export interface ICardField {
    label: string;
    value: string;
    iconClass?: string;
}
