import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
@Injectable()
export class AtlasDialogBoxService extends MatDialog {}
