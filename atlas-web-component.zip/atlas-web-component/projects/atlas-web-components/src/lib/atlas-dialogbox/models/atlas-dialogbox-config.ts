import { MatDialogConfig } from '@angular/material';

export class AtlasDialogBoxConfig extends MatDialogConfig {}
