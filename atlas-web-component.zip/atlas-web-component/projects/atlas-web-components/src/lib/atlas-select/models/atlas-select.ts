export interface IAtlasSelectModel {
    key: any;
    value: any;
    isDisabled?: boolean;
}
