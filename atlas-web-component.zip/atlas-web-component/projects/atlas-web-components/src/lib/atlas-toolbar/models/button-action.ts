export enum ButtonAction {
    Add,
    Edit,
    Remove,
    Refresh,
    ExportAsPdf,
    ExportAsExcel,
    Search,
    SearchClear,
    PrintInvoice,
    Sort,
    Filter,
    Upload,
}
