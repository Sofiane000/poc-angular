export interface IAtlasFooterbtn {
    text: string;
    title: string;
    action: any;
    isDisabled?: boolean;
    class?: string;
    primary?: boolean;
}
