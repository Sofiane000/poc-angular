export interface ISplitter {
    collapsible?: boolean;
    size?: any;
    min?: string;
    max?: string;
    resizable?: boolean;
    scrollable?: boolean;
    containsSplitter?: boolean;
    collapsed?: boolean;
}
