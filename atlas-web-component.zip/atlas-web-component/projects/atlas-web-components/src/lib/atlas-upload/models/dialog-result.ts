export interface IDialogResult {
    action: string;
    files: File[];
}
