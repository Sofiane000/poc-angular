export interface INavLink {
    label: string;
    link: string;
    index: number;
}
