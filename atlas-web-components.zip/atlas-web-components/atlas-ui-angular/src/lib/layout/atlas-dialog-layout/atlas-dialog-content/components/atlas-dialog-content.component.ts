import { Component, Input, OnInit } from '@angular/core';
@Component({
    selector: 'atlas-dialog-content',
    templateUrl: './atlas-dialog-content.component.html',
    styleUrls: ['./atlas-dialog-content.component.scss']
})
export class AtlasDialogContentComponent {
    constructor() {
    }
}
