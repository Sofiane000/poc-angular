
import { Component} from '@angular/core';
@Component({
    selector: 'atlas-content',
    templateUrl: './atlas-content.component.html',
    styleUrls: ['./atlas-content.component.scss']
})
export class AtlasContentComponent {
}
