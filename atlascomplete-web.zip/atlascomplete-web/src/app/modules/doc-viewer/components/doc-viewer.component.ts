import { Component } from '@angular/core';

@Component({
    selector: 'app-doc-viewer',
    templateUrl: 'doc-viewer.component.html',
    styleUrls: ['doc-viewer.component.scss']
})
export class DocumentViewerComponent {

}